package puzzles.slide.model;

public class SlideClientData {
    private int[][] grid;

    public SlideClientData(int[][] grid){
        this.grid = grid;
    }
}
